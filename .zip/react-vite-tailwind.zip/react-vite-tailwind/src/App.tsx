export const App = () => {
  return (
    <main className="h-screen w-screen flex items-center justify-center bg-gray-900">
      <h1 className="text-5xl font-bold text-white">Hello World!</h1>
    </main>
  )
}
