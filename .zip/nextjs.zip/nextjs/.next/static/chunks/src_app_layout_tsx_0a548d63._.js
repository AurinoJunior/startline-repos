(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[next]_internal_font_google_roboto_7197f6d_module_cbd8ebfb.css"
],
    source: "dynamic"
});
